--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: monitor_log_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.monitor_log_status_enum AS ENUM (
    'UP',
    'DOWN',
    'UNKNOWN'
);


ALTER TYPE public.monitor_log_status_enum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alert; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert (
    id integer NOT NULL,
    "alertType" character varying NOT NULL,
    message character varying NOT NULL,
    "sentAt" timestamp without time zone DEFAULT now() NOT NULL,
    "targetId" uuid
);


ALTER TABLE public.alert OWNER TO postgres;

--
-- Name: alert_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alert_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alert_id_seq OWNER TO postgres;

--
-- Name: alert_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alert_id_seq OWNED BY public.alert.id;


--
-- Name: domain_info; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.domain_info (
    id integer NOT NULL,
    "sslExpiryDate" timestamp without time zone,
    "domainExpiryDate" timestamp without time zone,
    "daysToSslExpiry" integer,
    "daysToDomainExpiry" integer,
    "domainName" character varying,
    "registrantName" character varying,
    "domainStatus" character varying,
    "registrarUrl" character varying,
    "domainId" character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "targetId" uuid
);


ALTER TABLE public.domain_info OWNER TO postgres;

--
-- Name: domain_info_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.domain_info_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.domain_info_id_seq OWNER TO postgres;

--
-- Name: domain_info_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.domain_info_id_seq OWNED BY public.domain_info.id;


--
-- Name: monitor_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monitor_log (
    id integer NOT NULL,
    "statusCode" integer NOT NULL,
    status public.monitor_log_status_enum DEFAULT 'UNKNOWN'::public.monitor_log_status_enum NOT NULL,
    "latencyMs" integer NOT NULL,
    error character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "targetId" uuid
);


ALTER TABLE public.monitor_log OWNER TO postgres;

--
-- Name: monitor_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.monitor_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.monitor_log_id_seq OWNER TO postgres;

--
-- Name: monitor_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.monitor_log_id_seq OWNED BY public.monitor_log.id;


--
-- Name: target; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.target (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "ownerId" character varying NOT NULL,
    name character varying NOT NULL,
    url character varying NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "domainInfoFound" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.target OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying NOT NULL,
    "phoneNumber" character varying NOT NULL,
    password character varying NOT NULL,
    name character varying NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: alert id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert ALTER COLUMN id SET DEFAULT nextval('public.alert_id_seq'::regclass);


--
-- Name: domain_info id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.domain_info ALTER COLUMN id SET DEFAULT nextval('public.domain_info_id_seq'::regclass);


--
-- Name: monitor_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitor_log ALTER COLUMN id SET DEFAULT nextval('public.monitor_log_id_seq'::regclass);


--
-- Data for Name: alert; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert (id, "alertType", message, "sentAt", "targetId") FROM stdin;
\.


--
-- Data for Name: domain_info; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.domain_info (id, "sslExpiryDate", "domainExpiryDate", "daysToSslExpiry", "daysToDomainExpiry", "domainName", "registrantName", "domainStatus", "registrarUrl", "domainId", "createdAt", "targetId") FROM stdin;
\.


--
-- Data for Name: monitor_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monitor_log (id, "statusCode", status, "latencyMs", error, "createdAt", "targetId") FROM stdin;
\.


--
-- Data for Name: target; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.target (id, "ownerId", name, url, "isActive", "domainInfoFound", "createdAt") FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, email, "phoneNumber", password, name, "isActive", "createdAt", "updatedAt") FROM stdin;
a19b311e-a786-4578-b4c2-5152d1d9da9c	user@example.com	+255746561545	$2b$10$glLcmaDe4xk16VrhY04b6uiIRHwPDFAVVKzgO4gV2tmwNYZEvRJke	John Doe	f	2025-06-09 20:29:02.549746	2025-06-09 20:29:02.549746
d8458d43-bb5f-49f0-867e-3b21cbe023c7	laysonndenza@gmail.com	+255759907751	$2b$10$Tq9lSGcIkhj15h.IERz97uqMYfbQXRnd0jNdY3AydA03ozbt4Bbfe	Layson	f	2025-06-09 21:30:52.997403	2025-06-09 21:30:52.997403
a61b4aaa-8f1c-4001-a5b8-942df095c99f	ericksanga@gmail.com	+255759901234	$2b$10$cY4CNkC1OXSDpc3hhrSh6u42ZgIySrZNs9U0/Vb7g3TvrCgjbHD8O	erick	f	2025-06-10 10:11:59.735579	2025-06-10 10:11:59.735579
f7e26f32-5257-44e7-aae1-19cb54e3c0a2	piusoscar@gmail.com	+255759567899	$2b$10$oeSrR6dmx.5HN7lArApPXOeKFg4C7.ymmKEEyEt7unRLGaMHLnS/q	pius	f	2025-06-10 10:14:49.591545	2025-06-10 10:14:49.591545
7c6b6614-38e3-48b7-a7c2-a834a6dc42c7	festondunguru@gmail.com	+255629686467	$2b$10$vTI0snuyQnPS3UhHs3aLvujqOnIRXp1VfYgajALuHMzHJjgGhqd3S	festo	f	2025-06-10 13:18:00.980778	2025-06-10 13:18:00.980778
da12e09c-a070-459c-beda-046becdd1515	mcharoprofg23@gmail.com	+255746561545	$2b$10$BrvuXZeO.IWnJarxvf2RfO2dDe2PYyVMd.NKt63P6sZFwkOwr25Su	mcharo	f	2025-06-10 13:50:26.891936	2025-06-10 13:50:26.891936
b4b3cc60-96b1-4673-abf1-111f2c6fb894	agnesgabriel@gmail.com	+255768696043	$2b$10$eQ0kO3DO7TXifSL/p/9Aeu2AsQd7tDlq4sjlaywFrxAVekqtkZQXS	agnes	f	2025-06-10 14:13:24.152926	2025-06-10 14:13:24.152926
\.


--
-- Name: alert_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alert_id_seq', 1, false);


--
-- Name: domain_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.domain_info_id_seq', 1, false);


--
-- Name: monitor_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.monitor_log_id_seq', 1, false);


--
-- Name: domain_info PK_2d5afefcff119a20d524dfd82b8; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.domain_info
    ADD CONSTRAINT "PK_2d5afefcff119a20d524dfd82b8" PRIMARY KEY (id);


--
-- Name: monitor_log PK_486c5ef88a5bb144bf44a0331af; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitor_log
    ADD CONSTRAINT "PK_486c5ef88a5bb144bf44a0331af" PRIMARY KEY (id);


--
-- Name: target PK_9d962204b13c18851ea88fc72f3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.target
    ADD CONSTRAINT "PK_9d962204b13c18851ea88fc72f3" PRIMARY KEY (id);


--
-- Name: alert PK_ad91cad659a3536465d564a4b2f; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert
    ADD CONSTRAINT "PK_ad91cad659a3536465d564a4b2f" PRIMARY KEY (id);


--
-- Name: user PK_cace4a159ff9f2512dd42373760; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);


--
-- Name: target UQ_3cf9735515c33c00a96e8f23ce2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.target
    ADD CONSTRAINT "UQ_3cf9735515c33c00a96e8f23ce2" UNIQUE (url);


--
-- Name: user UQ_e12875dfb3b1d92d7d7c5377e22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e22" UNIQUE (email);


--
-- Name: monitor_log FK_7f22f1fe940bfada7a8c94df39d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitor_log
    ADD CONSTRAINT "FK_7f22f1fe940bfada7a8c94df39d" FOREIGN KEY ("targetId") REFERENCES public.target(id) ON DELETE CASCADE;


--
-- Name: domain_info FK_95f34b2e7367f5ec56c34ed3ca7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.domain_info
    ADD CONSTRAINT "FK_95f34b2e7367f5ec56c34ed3ca7" FOREIGN KEY ("targetId") REFERENCES public.target(id) ON DELETE CASCADE;


--
-- Name: alert FK_c6d71418a9cb37b264326452872; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert
    ADD CONSTRAINT "FK_c6d71418a9cb37b264326452872" FOREIGN KEY ("targetId") REFERENCES public.target(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

